import java.util.ArrayList;

import com.sun.swing.internal.plaf.basic.resources.basic_de;

//SUBMIT
public class BNode implements BNodeInterface {

	// ///////////////////BEGIN DO NOT CHANGE ///////////////////
	// ///////////////////BEGIN DO NOT CHANGE ///////////////////
	// ///////////////////BEGIN DO NOT CHANGE ///////////////////
	private final int t;
	private int numOfBlocks;
	private boolean isLeaf;
	private ArrayList<Block> blocksList;
	private ArrayList<BNode> childrenList;

	/**
	 * Constructor for creating a node with a single child.<br>
	 * Useful for creating a new root.
	 */
	public BNode(int t, BNode firstChild) {
		this(t, false, 0);
		this.childrenList.add(firstChild);
	}

	/**
	 * Constructor for creating a <b>leaf</b> node with a single block.
	 */
	public BNode(int t, Block firstBlock) {
		this(t, true, 1);
		this.blocksList.add(firstBlock);
	}

	public BNode(int t, boolean isLeaf, int numOfBlocks) {
		this.t = t;
		this.isLeaf = isLeaf;
		this.numOfBlocks = numOfBlocks;
		this.blocksList = new ArrayList<Block>();
		this.childrenList = new ArrayList<BNode>();
	}

	// For testing purposes.
	public BNode(int t, int numOfBlocks, boolean isLeaf,
			ArrayList<Block> blocksList, ArrayList<BNode> childrenList) {
		this.t = t;
		this.numOfBlocks = numOfBlocks;
		this.isLeaf = isLeaf;
		this.blocksList = blocksList;
		this.childrenList = childrenList;
	}

	@Override
	public int getT() {
		return t;
	}

	@Override
	public int getNumOfBlocks() {
		return numOfBlocks;
	}

	@Override
	public boolean isLeaf() {
		return isLeaf;
	}

	@Override
	public ArrayList<Block> getBlocksList() {
		return blocksList;
	}

	@Override
	public ArrayList<BNode> getChildrenList() {
		return childrenList;
	}

	@Override
	public boolean isFull() {
		return numOfBlocks == 2 * t - 1;
	}

	@Override
	public boolean isMinSize() {
		return numOfBlocks == t - 1;
	}

	@Override
	public boolean isEmpty() {
		return numOfBlocks == 0;
	}

	@Override
	public int getBlockKeyAt(int indx) {
		return blocksList.get(indx).getKey();
	}

	@Override
	public Block getBlockAt(int indx) {
		return blocksList.get(indx);
	}

	@Override
	public BNode getChildAt(int indx) {
		return childrenList.get(indx);
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((blocksList == null) ? 0 : blocksList.hashCode());
		result = prime * result
				+ ((childrenList == null) ? 0 : childrenList.hashCode());
		result = prime * result + (isLeaf ? 1231 : 1237);
		result = prime * result + numOfBlocks;
		result = prime * result + t;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BNode other = (BNode) obj;
		if (blocksList == null) {
			if (other.blocksList != null)
				return false;
		} else if (!blocksList.equals(other.blocksList))
			return false;
		if (childrenList == null) {
			if (other.childrenList != null)
				return false;
		} else if (!childrenList.equals(other.childrenList))
			return false;
		if (isLeaf != other.isLeaf)
			return false;
		if (numOfBlocks != other.numOfBlocks)
			return false;
		if (t != other.t)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BNode [t=" + t + ", numOfBlocks=" + numOfBlocks + ", isLeaf="
				+ isLeaf + ", blocksList=" + blocksList + ", childrenList="
				+ childrenList + "]";
	}

	// ///////////////////DO NOT CHANGE END///////////////////
	// ///////////////////DO NOT CHANGE END///////////////////
	// ///////////////////DO NOT CHANGE END///////////////////



	@Override
	public Block search(int key) {
		int i=0;
		while (i<=blocksList.size() && key>blocksList.get(i).getKey())
			//go through the keys on the node that their value is smaller than key
			i++;
		if (i<blocksList.size()&& key==blocksList.get(i).getKey())
			//returns the block with the amount of key
			return blocksList.get(i);
		if (isLeaf)
			return null;
		
		return childrenList.get(i).search(key);

	}

	@Override
	public void insertNonFull(Block d) {
		//1
		int i=numOfBlocks-1;
		//2
		if (isLeaf()){
			//3 if leaf then find his location 
			while (i>=0&&(d.getKey())<(blocksList.get(i).getKey())){
				//4
				//	blocksList.add(i+1, blocksList.get(i));
				//5
				i--;
			}
			//6 insert the key to his right place
			blocksList.add(i+1, d);
			//7
			numOfBlocks++;

		}
		//9
		else{
			//10 find the child that it should be inserted to
			while (i>=1 && d.getKey()<blocksList.get(i).getKey())
				//11
				i--;
			//12
			i++;
			//14 if child is full do split
			if (childrenList.get(i).isFull()){
				//15
				childrenList.get(i).splitChild(this, i);
				//16
				if (d.getKey()>blocksList.get(i).getKey())
					i++;
				//17 insert the child recursively
				childrenList.get(i).insertNonFull(d);
			}
		}
	}
	public void splitChild(BNode x, int i){
		BNode z=new BNode(t, isLeaf(),t-1);//1 
		//2 copy the right keys of x to z
		for (int j=0; j<t-1; j++){
			z.blocksList.add(blocksList.get(j+t));
		}
		//3 copy the right children of x to z children list
		if (!isLeaf)
			for (int k=0; k<t; k++)
				z.childrenList.add(childrenList.get(k+t));
		//4
		numOfBlocks=t-1;


		//5 add z  (to x father) children list in the right place

		int j=i-1;
		while (j>=0 && childrenList.get(j)!=x)

			j--;
		//6		
		childrenList.add(j+1, z);
		//7 add the former middle  key of x to  (to x father) in its right place

		blocksList.add(j+1, x.blocksList.get(t));
		//8
		x.numOfBlocks=t-1;
		numOfBlocks++;
	}

	@Override
	public void delete(int key) {
		int i=0;
		while (i<numOfBlocks&&blocksList.get(i).getKey()!=key)
			i++;
		if (key==blocksList.get(i).getKey()){//found the key to remove


			if (isLeaf){

				blocksList.remove(i);//just remove
				numOfBlocks--;}
			
			else/*not leaf*/{
				if (childrenList.get(i).numOfBlocks>=t)/*child in left has t nodes+*/{
					//replace key with its predecessor
					int numBlocksChild=childrenList.get(i).numOfBlocks;
					blocksList.set(i, childrenList.get(i).blocksList.get(numBlocksChild));
					childrenList.get(i).delete(blocksList.get(i).getKey());
				}/*child in right has t nodes+*/
				else if (childrenList.get(i+1).numOfBlocks>=t){
					//replace key with successor
					blocksList.set(i+1, childrenList.get(i).blocksList.get(0));
					childrenList.get(i+1).delete(blocksList.get(i).getKey());
				}
				else{//x is in k and both children has t-1 keys
					//delete
					blocksList.remove(i);//just remove
					//merge children
					for (int j=0;j<t-1;j++)
						childrenList.get(i-1).insertNonFull(childrenList.get(i).getBlockAt(j));
					childrenList.remove(i);
					numOfBlocks--;
				}
				}}
	
			else{//key not found
				if (!isLeaf){
					if (childrenList.get(i).isMinSize()){
						if (i>0&&childrenList.get(i-1).numOfBlocks>=t){//loan from left sibling
							childrenList.get(i).blocksList.add(0, blocksList.get(i));
							childrenList.get(i).numOfBlocks++;
							Block temp=childrenList.get(i-1).getBlockAt(childrenList.get(i-1).numOfBlocks-1);
							blocksList.set(i, temp);
							childrenList.remove(i-1);
						}
						else{
							if (i<numOfBlocks&&childrenList.get(i+1).numOfBlocks>=t){//loan from right sibling
								childrenList.get(i).blocksList.add(childrenList.get(i+1).numOfBlocks-1, blocksList.get(i));
								childrenList.get(i).numOfBlocks++;
								Block temp=childrenList.get(i+1).getBlockAt(0);
								blocksList.set(i-1, temp);
								childrenList.remove(i+1);
							}
							else{//both immediate siblings has min size keys - merge
								if (i<numOfBlocks){//merge with right sibling
									int nextBlock=childrenList.get(i+1).numOfBlocks;
									childrenList.get(i).blocksList.add(blocksList.get(i));
									for (int j=0;j<nextBlock;j++){
										childrenList.get(i).blocksList.add(childrenList.get(i+1).blocksList.get(j));
										childrenList.get(i).numOfBlocks++;
									}
									blocksList.remove(i);
									numOfBlocks--;
									childrenList.remove(i+1);
								}
								else{//the right child could be merged only with left sibling
									int nextBlock=childrenList.get(i-1).numOfBlocks;
									childrenList.get(i).blocksList.add(blocksList.get(i));
									for (int j=0;j<nextBlock;j++){
										childrenList.get(i).blocksList.add(childrenList.get(i-1).blocksList.get(j));
										childrenList.get(i).numOfBlocks++;
									}
									blocksList.remove(i);
									numOfBlocks--;
									childrenList.remove(i-1);
								}
							}


						}
						childrenList.get(i).delete(key);
					}
				}
			}
		}




		@Override
		public MerkleBNode createHashNode() {
			// TODO Auto-generated method stub
			return null;
		}



	}
